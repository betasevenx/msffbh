# MS Arch

MS Arch generates production-ready system architectures from plain-English
descriptions and a target tech stack. Built with TanStack Start, React 19,
Tailwind CSS, and Microsoft Azure AI Foundry.

## Local development

```bash
npm install
cp .env.example .env   # then fill in your Azure AI Foundry values
npm run dev
```

## Environment variables

Set these in your shell, `.env` file, or hosting provider:

| Name | Description |
| --- | --- |
| `AZURE_FOUNDRY_ENDPOINT` | e.g. `https://your-resource.services.ai.azure.com` |
| `AZURE_FOUNDRY_API_KEY` | API key from the Azure AI Foundry portal |
| `AZURE_FOUNDRY_DEPLOYMENT` | Model deployment name, e.g. `gpt-4o-mini` |
| `AZURE_FOUNDRY_API_VERSION` | Optional, defaults to `2024-10-21` |

## Deploying to Netlify

1. Push the repo to GitHub.
2. In Netlify, **Add new site → Import an existing project** and pick the repo.
3. Build settings are auto-detected from `netlify.toml`
   (`npm run build`, publish dir `dist/client`). The Nitro `netlify` preset
   generates the serverless function for SSR automatically.
4. Go to **Site settings → Environment variables** and add the four Azure
   variables above. **Do not** commit real keys to `.env`.
5. Trigger a deploy. SSR routes run on Netlify Functions; static assets are
   served from the CDN.

That's it — no other configuration is required.
