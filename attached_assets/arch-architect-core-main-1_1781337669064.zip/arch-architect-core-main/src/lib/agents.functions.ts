import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Multi-agent generator powered by Microsoft Azure AI Foundry.
 *
 * Set these in your `.env` (or your deployment environment):
 *   AZURE_FOUNDRY_ENDPOINT   e.g. https://<your-resource>.services.ai.azure.com
 *   AZURE_FOUNDRY_API_KEY    your Azure AI Foundry API key
 *   AZURE_FOUNDRY_DEPLOYMENT model deployment name, e.g. gpt-4o-mini
 *   AZURE_FOUNDRY_API_VERSION (optional, defaults to 2024-10-21)
 *
 * The key is read on the server only — it never reaches the browser.
 */

const AGENT_IDS = ["architecture", "schema", "readme", "prompt"] as const;
type AgentId = (typeof AGENT_IDS)[number];

const RunAgentInput = z.object({
  agentId: z.enum(AGENT_IDS),
  concept: z.string().min(3),
  stack: z.string().min(1),
  deepThink: z.boolean().optional().default(false),
});

const TRUTH_RULES = `
ACCURACY RULES (must follow):
- Do not invent libraries, APIs, versions, or services. Use only widely-known, stable conventions.
- If a detail is not given, state your assumption explicitly at the top.
- Prefer plain, conventional patterns over clever or obscure ones.
- Do not mention which AI model or provider produced this output.
- No filler, no apologies, no meta commentary.
`.trim();

const DEEP_BRIEF = `
REFERENCE PRINCIPLES (apply silently when in deep mode):
- Classify scale tier first: T1 0-1K / T2 1K-100K / T3 100K-1M / T4 1M+.
- Security: TLS, JWT (RS256), bcrypt cost>=12, RBAC + RLS, input validation, rate limits, secrets vault, audit logs.
- Data: relational by default; index FKs; read replicas at T3; Redis for hot reads; queues for heavy writes.
- Reliability: idempotent writes, retries + backoff + DLQ, health checks, graceful shutdown, circuit breakers.
- Observability: structured logs + traces (OTel) + metrics (RED/USE) + alerts on SLOs.
- Cost: managed services first; serverless for spiky load; autoscale on real signals.
`.trim();

const AGENTS: Record<AgentId, { system: (deep: boolean) => string; user: (c: string, s: string) => string }> = {
  architecture: {
    system: (deep) =>
      `You are a senior systems architect. Produce a clear ASCII system architecture diagram (boxes + arrows) showing client, API, services, data layer, auth, cache, queues, and storage as appropriate. Output ONLY the diagram inside a single fenced code block, no prose.\n\n${TRUTH_RULES}${
        deep ? `\n\n${DEEP_BRIEF}` : ""
      }`,
    user: (concept, stack) =>
      `Concept:\n${concept}\n\nTarget stack: ${stack}\n\nDraw the production architecture.`,
  },
  schema: {
    system: (deep) =>
      `You are a senior database engineer. Produce a normalized PostgreSQL schema (CREATE TABLE with PKs, FKs, indexes, sensible types, and RLS hints as SQL comments). Output ONLY SQL in a single fenced code block, no prose.\n\n${TRUTH_RULES}${
        deep ? `\n\n${DEEP_BRIEF}` : ""
      }`,
    user: (concept, stack) => `Concept:\n${concept}\n\nTarget stack: ${stack}\n\nDesign the schema.`,
  },
  readme: {
    system: (deep) =>
      `You are writing a README.md for a beginner ("vibe coder") who has never studied system design. Use plain English, short sentences, friendly tone, analogies. Explain WHY each piece exists. Define jargon inline. Sections: What this app does, How it works, The pieces, Getting started (copy-paste commands), Where things live, Common questions. Output ONLY the README markdown.\n\n${TRUTH_RULES}${
        deep ? `\n\nAdd a short "Going to production" section (backups, monitoring, secrets, rate limits).` : ""
      }`,
    user: (concept, stack) =>
      `Concept:\n${concept}\n\nTarget stack: ${stack}\n\nWrite a beginner-friendly README.md.`,
  },
  prompt: {
    system: (deep) =>
      `You are a prompt engineer. Produce one comprehensive master prompt another LLM could use to build the described system end-to-end. Sections: Assumptions, Logic Workflow, Data Handling Structure, Application Screen Map, API Contract, Implementation Order. Output ONLY the prompt as plain markdown.\n\n${TRUTH_RULES}${
        deep ? `\n\n${DEEP_BRIEF}` : ""
      }`,
    user: (concept, stack) =>
      `Concept:\n${concept}\n\nTarget stack: ${stack}\n\nWrite the master build prompt.`,
  },
};

async function callAzureFoundry(system: string, user: string, deep: boolean): Promise<string> {
  const endpoint = process.env.AZURE_FOUNDRY_ENDPOINT;
  const apiKey = process.env.AZURE_FOUNDRY_API_KEY;
  const deployment = process.env.AZURE_FOUNDRY_DEPLOYMENT;
  const apiVersion = process.env.AZURE_FOUNDRY_API_VERSION ?? "2024-10-21";

  if (!endpoint || !apiKey || !deployment) {
    throw new Error(
      "Azure AI Foundry is not configured. Set AZURE_FOUNDRY_ENDPOINT, AZURE_FOUNDRY_API_KEY, and AZURE_FOUNDRY_DEPLOYMENT in your environment.",
    );
  }

  const base = endpoint.replace(/\/+$/, "");
  const url = `${base}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": apiKey },
    body: JSON.stringify({
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      temperature: deep ? 0.3 : 0.6,
      max_tokens: deep ? 3000 : 1500,
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Azure AI Foundry ${res.status}: ${body.slice(0, 300)}`);
  }
  const json = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  return json.choices?.[0]?.message?.content?.trim() ?? "";
}

export const runAgent = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => RunAgentInput.parse(input))
  .handler(async ({ data }) => {
    const def = AGENTS[data.agentId];
    try {
      const text = await callAzureFoundry(
        def.system(data.deepThink),
        def.user(data.concept, data.stack),
        data.deepThink,
      );
      return { agentId: data.agentId, text: text || "> ⚠️ Empty response from the AI service.", error: !text };
    } catch (err) {
      console.error(`agent ${data.agentId} failed`, err);
      const msg = err instanceof Error ? err.message : "Unknown error";
      return {
        agentId: data.agentId,
        text: `> ⚠️ This section could not be generated.\n>\n> ${msg}`,
        error: true,
      };
    }
  });
